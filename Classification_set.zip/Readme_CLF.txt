The entire code is available in the jupyter notebook file Group31_Classification_Project.ipynb

The Last Cell in notebook file contains the scripts/function call to activate whole classification problems
All the above cells contains the Classes for the Classification Data Set

The Remaining files in this folder represent the Data

Please open the ipynb file and go to last cell  and press Ctrl + Ent to run the classification part of project

It might take 30 mins to 1 hr, you can see the commments as the code progresses 